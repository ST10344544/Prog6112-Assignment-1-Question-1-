
package student_management_application;




public class Student_Management_Application {

    
    
         public static void main(String[] args) {
        
                  Student.SplashScreen();
    
    }
    
    
}
